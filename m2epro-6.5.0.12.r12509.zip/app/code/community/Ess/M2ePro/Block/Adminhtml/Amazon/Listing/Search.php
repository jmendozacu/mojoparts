<?php

/*
 * @author     M2E Pro Developers Team
 * @copyright  M2E LTD
 * @license    Commercial use is forbidden
 */

class Ess_M2ePro_Block_Adminhtml_Amazon_Listing_Search extends Ess_M2ePro_Block_Adminhtml_Widget_Container
{
    //########################################

    public function __construct()
    {
        parent::__construct();

        // Initialization block
        // ---------------------------------------
        $this->setId('amazonListingSearch');
        // ---------------------------------------
    }

    protected function _beforeToHtml()
    {
        parent::_beforeToHtml();

        $listingType = $this->getRequest()->getParam('listing_type', false);
        $gridBlock = $listingType == Ess_M2ePro_Block_Adminhtml_Listing_Search_Switcher::LISTING_TYPE_LISTING_OTHER
            ? $this->getLayout()->createBlock('M2ePro/adminhtml_amazon_listing_search_other_grid')
            : $this->getLayout()->createBlock('M2ePro/adminhtml_amazon_listing_search_m2ePro_grid');

        $this->setChild('help', $this->getLayout()->createBlock('M2ePro/adminhtml_amazon_listing_search_help'));
        $this->setChild('grid', $gridBlock);
    }

    protected function _toHtml()
    {
        return $this->getTemplatesButtonJavascript() .
            parent::_toHtml() .
            $this->getChildHtml('help') .
            $this->getChildHtml('grid');
    }

    //########################################

    protected function getTemplatesButtonJavascript()
    {
        $data = array(
            'target_css_class' => 'templates-drop-down',
            'items'            => $this->getTemplatesButtonDropDownItems()
        );
        $dropDownBlock = $this->getLayout()->createBlock('M2ePro/adminhtml_widget_button_dropDown');
        $dropDownBlock->setData($data);

        return $dropDownBlock->toHtml();
    }

    protected function getTemplatesButtonDropDownItems()
    {
        $items = array();

        $filter = base64_encode('component_mode=' . Ess_M2ePro_Helper_Component_Amazon::NICK);

        // ---------------------------------------
        $url = $this->getUrl('*/adminhtml_amazon_template_sellingFormat/index', array('filter' => $filter));
        $items[] = array(
            'url' => $url,
            'label' => Mage::helper('M2ePro')->__('Selling Format Policies'),
            'target' => '_blank'
        );
        // ---------------------------------------

        // ---------------------------------------
        $url = $this->getUrl('*/adminhtml_amazon_template_synchronization/index', array('filter' => $filter));
        $items[] = array(
            'url' => $url,
            'label' => Mage::helper('M2ePro')->__('Synchronization Policies'),
            'target' => '_blank'
        );
        // ---------------------------------------

        // ---------------------------------------
        $url = $this->getUrl(
            '*/adminhtml_amazon_template_description/index'
        );
        $items[] = array(
            'url' => $url,
            'label' => Mage::helper('M2ePro')->__('%amazon% Description Policies',
                                                   Mage::helper('M2ePro/Component_Amazon')->getTitle()),
            'target' => '_blank'
        );
        // ---------------------------------------

        return $items;
    }

    //########################################
}