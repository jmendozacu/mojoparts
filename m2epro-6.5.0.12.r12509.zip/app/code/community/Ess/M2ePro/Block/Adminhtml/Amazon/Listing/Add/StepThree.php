<?php

/*
 * @author     M2E Pro Developers Team
 * @copyright  M2E LTD
 * @license    Commercial use is forbidden
 */

class Ess_M2ePro_Block_Adminhtml_Amazon_Listing_Add_StepThree extends Mage_Adminhtml_Block_Widget_Form_Container
{
    //########################################

    public function __construct($attributes)
    {
        parent::__construct();

        $this->setData($attributes);

        // Initialization block
        // ---------------------------------------
        $this->setId('amazonListingAddStepThree');
        $this->_blockGroup = 'M2ePro';
        $this->_controller = 'adminhtml_amazon_listing';
        $this->_mode = 'add';
        // ---------------------------------------

        // Set header text
        // ---------------------------------------
        $this->_headerText = Mage::helper('M2ePro')->__("Creating A New M2E Pro Listing");
        // ---------------------------------------

        // Set buttons actions
        // ---------------------------------------
        $this->removeButton('back');
        $this->removeButton('reset');
        $this->removeButton('delete');
        $this->removeButton('add');
        $this->removeButton('save');
        $this->removeButton('edit');
        // ---------------------------------------

        // ---------------------------------------
        $url = $this->getUrl('*/adminhtml_amazon_listing_create/index', array(
            '_current' => true,
            'step' => '2'
        ));
        $this->_addButton('back', array(
            'label'     => Mage::helper('M2ePro')->__('Previous Step'),
            'onclick'   => 'CommonHandlerObj.back_click(\'' . $url . '\')',
            'class'     => 'back'
        ));
        // ---------------------------------------

        // ---------------------------------------
        $url = $this->getUrl('*/adminhtml_amazon_listing_create/index', array(
            '_current' => true
        ));
        $this->_addButton('save_and_next', array(
            'label'     => Mage::helper('M2ePro')->__('Next Step'),
            'onclick'   => 'CommonHandlerObj.save_click(\'' . $url . '\')',
            'class'     => 'next'
        ));
        // ---------------------------------------
    }

    //########################################
}